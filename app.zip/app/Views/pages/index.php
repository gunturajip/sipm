<?= $this->extend('layout/template_guest'); ?>

<?= $this->section('content'); ?>
<?= $this->endSection(); ?>