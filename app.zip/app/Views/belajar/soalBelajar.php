<?= $this->extend('layout/template_belajar'); ?>

<?= $this->section('content'); ?>

<div class="container-md py-5">
    <div class="row py-3 g-2">
        <div class="col-md-6">
            <div class="p-2 border bg-light h-auto">
                <h1>Soal</h1>

            </div>
        </div>
        <div class="col-md-6">
            <div class="p-2 border bg-light h-auto">
                <h1>Jawaban</h1>

            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>