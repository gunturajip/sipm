<?= $this->extend('layout/template_belajar'); ?>

<?= $this->section('content'); ?>

<div class="container-md">
    <div class="row h-100 d-flex justify-content-center align-items-center">
        <div class="col-md-8 h-auto m-0">
            <div class="ratio ratio-16x9">
                <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="YouTube video player" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>